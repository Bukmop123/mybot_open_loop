#ifndef _ROS_operator_input_operator_cmds_msg_h
#define _ROS_operator_input_operator_cmds_msg_h

#include <stdint.h>
#include <string.h>
#include <stdlib.h>
#include "ros/msg.h"
#include "std_msgs/Header.h"
#include "geometry_msgs/Twist.h"

namespace operator_input
{

  class operator_cmds_msg : public ros::Msg
  {
    public:
      typedef std_msgs::Header _header_type;
      _header_type header;
      typedef geometry_msgs::Twist _robot_direction_type;
      _robot_direction_type robot_direction;

    operator_cmds_msg():
      header(),
      robot_direction()
    {
    }

    virtual int serialize(unsigned char *outbuffer) const
    {
      int offset = 0;
      offset += this->header.serialize(outbuffer + offset);
      offset += this->robot_direction.serialize(outbuffer + offset);
      return offset;
    }

    virtual int deserialize(unsigned char *inbuffer)
    {
      int offset = 0;
      offset += this->header.deserialize(inbuffer + offset);
      offset += this->robot_direction.deserialize(inbuffer + offset);
     return offset;
    }

    const char * getType(){ return "operator_input/operator_cmds_msg"; };
    const char * getMD5(){ return "5885a1a47df401d5fa2fc073df3d53d0"; };

  };

}
#endif
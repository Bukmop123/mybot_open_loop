#ifndef _ROS_gazebo_plugins_msgMybot_jointInterface_h
#define _ROS_gazebo_plugins_msgMybot_jointInterface_h

#include <stdint.h>
#include <string.h>
#include <stdlib.h>
#include "ros/msg.h"
#include "std_msgs/Header.h"

namespace gazebo_plugins
{

  class msgMybot_jointInterface : public ros::Msg
  {
    public:
      typedef std_msgs::Header _header_type;
      _header_type header;
      typedef float _left_type;
      _left_type left;
      typedef float _right_type;
      _right_type right;

    msgMybot_jointInterface():
      header(),
      left(0),
      right(0)
    {
    }

    virtual int serialize(unsigned char *outbuffer) const
    {
      int offset = 0;
      offset += this->header.serialize(outbuffer + offset);
      offset += serializeAvrFloat64(outbuffer + offset, this->left);
      offset += serializeAvrFloat64(outbuffer + offset, this->right);
      return offset;
    }

    virtual int deserialize(unsigned char *inbuffer)
    {
      int offset = 0;
      offset += this->header.deserialize(inbuffer + offset);
      offset += deserializeAvrFloat64(inbuffer + offset, &(this->left));
      offset += deserializeAvrFloat64(inbuffer + offset, &(this->right));
     return offset;
    }

    const char * getType(){ return "gazebo_plugins/msgMybot_jointInterface"; };
    const char * getMD5(){ return "8f32685125452f5bdf68130369af5296"; };

  };

}
#endif
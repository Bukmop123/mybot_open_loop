// Auto-generated. Do not edit!

// (in-package mybot_msg.msg)


"use strict";

let _serializer = require('../base_serialize.js');
let _deserializer = require('../base_deserialize.js');
let _finder = require('../find.js');
let std_msgs = _finder('std_msgs');

//-----------------------------------------------------------

class msgMybot_basicMovement {
  constructor() {
    this.header = new std_msgs.msg.Header();
    this.leg_velocity_mode = false;
    this.mecanum_movement_mode = false;
    this.stabilisize_base_link_mode = false;
    this.stabilisize_ignore_front = false;
    this.stabilisize_ignore_back = false;
    this.robot_x = 0.0;
    this.robot_y = 0.0;
    this.robot_zrot = 0.0;
    this.left_front_leg = 0.0;
    this.left_back_leg = 0.0;
    this.right_front_leg = 0.0;
    this.right_back_leg = 0.0;
  }

  static serialize(obj, bufferInfo) {
    // Serializes a message object of type msgMybot_basicMovement
    // Serialize message field [header]
    bufferInfo = std_msgs.msg.Header.serialize(obj.header, bufferInfo);
    // Serialize message field [leg_velocity_mode]
    bufferInfo = _serializer.bool(obj.leg_velocity_mode, bufferInfo);
    // Serialize message field [mecanum_movement_mode]
    bufferInfo = _serializer.bool(obj.mecanum_movement_mode, bufferInfo);
    // Serialize message field [stabilisize_base_link_mode]
    bufferInfo = _serializer.bool(obj.stabilisize_base_link_mode, bufferInfo);
    // Serialize message field [stabilisize_ignore_front]
    bufferInfo = _serializer.bool(obj.stabilisize_ignore_front, bufferInfo);
    // Serialize message field [stabilisize_ignore_back]
    bufferInfo = _serializer.bool(obj.stabilisize_ignore_back, bufferInfo);
    // Serialize message field [robot_x]
    bufferInfo = _serializer.float64(obj.robot_x, bufferInfo);
    // Serialize message field [robot_y]
    bufferInfo = _serializer.float64(obj.robot_y, bufferInfo);
    // Serialize message field [robot_zrot]
    bufferInfo = _serializer.float64(obj.robot_zrot, bufferInfo);
    // Serialize message field [left_front_leg]
    bufferInfo = _serializer.float64(obj.left_front_leg, bufferInfo);
    // Serialize message field [left_back_leg]
    bufferInfo = _serializer.float64(obj.left_back_leg, bufferInfo);
    // Serialize message field [right_front_leg]
    bufferInfo = _serializer.float64(obj.right_front_leg, bufferInfo);
    // Serialize message field [right_back_leg]
    bufferInfo = _serializer.float64(obj.right_back_leg, bufferInfo);
    return bufferInfo;
  }

  static deserialize(buffer) {
    //deserializes a message object of type msgMybot_basicMovement
    let tmp;
    let len;
    let data = new msgMybot_basicMovement();
    // Deserialize message field [header]
    tmp = std_msgs.msg.Header.deserialize(buffer);
    data.header = tmp.data;
    buffer = tmp.buffer;
    // Deserialize message field [leg_velocity_mode]
    tmp = _deserializer.bool(buffer);
    data.leg_velocity_mode = tmp.data;
    buffer = tmp.buffer;
    // Deserialize message field [mecanum_movement_mode]
    tmp = _deserializer.bool(buffer);
    data.mecanum_movement_mode = tmp.data;
    buffer = tmp.buffer;
    // Deserialize message field [stabilisize_base_link_mode]
    tmp = _deserializer.bool(buffer);
    data.stabilisize_base_link_mode = tmp.data;
    buffer = tmp.buffer;
    // Deserialize message field [stabilisize_ignore_front]
    tmp = _deserializer.bool(buffer);
    data.stabilisize_ignore_front = tmp.data;
    buffer = tmp.buffer;
    // Deserialize message field [stabilisize_ignore_back]
    tmp = _deserializer.bool(buffer);
    data.stabilisize_ignore_back = tmp.data;
    buffer = tmp.buffer;
    // Deserialize message field [robot_x]
    tmp = _deserializer.float64(buffer);
    data.robot_x = tmp.data;
    buffer = tmp.buffer;
    // Deserialize message field [robot_y]
    tmp = _deserializer.float64(buffer);
    data.robot_y = tmp.data;
    buffer = tmp.buffer;
    // Deserialize message field [robot_zrot]
    tmp = _deserializer.float64(buffer);
    data.robot_zrot = tmp.data;
    buffer = tmp.buffer;
    // Deserialize message field [left_front_leg]
    tmp = _deserializer.float64(buffer);
    data.left_front_leg = tmp.data;
    buffer = tmp.buffer;
    // Deserialize message field [left_back_leg]
    tmp = _deserializer.float64(buffer);
    data.left_back_leg = tmp.data;
    buffer = tmp.buffer;
    // Deserialize message field [right_front_leg]
    tmp = _deserializer.float64(buffer);
    data.right_front_leg = tmp.data;
    buffer = tmp.buffer;
    // Deserialize message field [right_back_leg]
    tmp = _deserializer.float64(buffer);
    data.right_back_leg = tmp.data;
    buffer = tmp.buffer;
    return {
      data: data,
      buffer: buffer
    }
  }

  static datatype() {
    // Returns string type for a message object
    return 'mybot_msg/msgMybot_basicMovement';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '755012f30d0d61b6461f9575f553ddeb';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    Header header #Header for message type
    bool leg_velocity_mode #Modes
    bool mecanum_movement_mode #
    bool stabilisize_base_link_mode #
    bool stabilisize_ignore_front #
    bool stabilisize_ignore_back #
    float64 robot_x #robot front movement Basic movement commands
    float64 robot_y #robot side movement
    float64 robot_zrot #robot z rotation
    float64 left_front_leg #front arm angle or up/down movement 
    float64 left_back_leg #back arm angle or up/down movement
    float64 right_front_leg #front arm angle or up/down movement 
    float64 right_back_leg #back arm angle or up/down movement
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    ================================================================================
    MSG: std_msgs/Header
    # Standard metadata for higher-level stamped data types.
    # This is generally used to communicate timestamped data 
    # in a particular coordinate frame.
    # 
    # sequence ID: consecutively increasing ID 
    uint32 seq
    #Two-integer timestamp that is expressed as:
    # * stamp.sec: seconds (stamp_secs) since epoch (in Python the variable is called 'secs')
    # * stamp.nsec: nanoseconds since stamp_secs (in Python the variable is called 'nsecs')
    # time-handling sugar is provided by the client library
    time stamp
    #Frame this data is associated with
    # 0: no frame
    # 1: global frame
    string frame_id
    
    `;
  }

};

module.exports = msgMybot_basicMovement;

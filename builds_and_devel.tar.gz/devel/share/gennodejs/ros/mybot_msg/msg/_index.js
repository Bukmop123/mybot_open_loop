
"use strict";

let msgMybot_basicMovement = require('./msgMybot_basicMovement.js');
let msgMybot_detailMovement = require('./msgMybot_detailMovement.js');

module.exports = {
  msgMybot_basicMovement: msgMybot_basicMovement,
  msgMybot_detailMovement: msgMybot_detailMovement,
};

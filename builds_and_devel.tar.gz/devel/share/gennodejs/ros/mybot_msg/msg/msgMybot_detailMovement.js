// Auto-generated. Do not edit!

// (in-package mybot_msg.msg)


"use strict";

let _serializer = require('../base_serialize.js');
let _deserializer = require('../base_deserialize.js');
let _finder = require('../find.js');
let std_msgs = _finder('std_msgs');

//-----------------------------------------------------------

class msgMybot_detailMovement {
  constructor() {
    this.header = new std_msgs.msg.Header();
    this.left_wheel = 0.0;
    this.right_wheel = 0.0;
    this.base_to_left_front_leg = 0.0;
    this.base_to_left_back_leg = 0.0;
    this.base_to_right_front_leg = 0.0;
    this.base_to_right_back_leg = 0.0;
    this.wheel_to_left_front_leg = 0.0;
    this.wheel_to_left_back_leg = 0.0;
    this.wheel_to_right_front_leg = 0.0;
    this.wheel_to_right_back_leg = 0.0;
  }

  static serialize(obj, bufferInfo) {
    // Serializes a message object of type msgMybot_detailMovement
    // Serialize message field [header]
    bufferInfo = std_msgs.msg.Header.serialize(obj.header, bufferInfo);
    // Serialize message field [left_wheel]
    bufferInfo = _serializer.float64(obj.left_wheel, bufferInfo);
    // Serialize message field [right_wheel]
    bufferInfo = _serializer.float64(obj.right_wheel, bufferInfo);
    // Serialize message field [base_to_left_front_leg]
    bufferInfo = _serializer.float64(obj.base_to_left_front_leg, bufferInfo);
    // Serialize message field [base_to_left_back_leg]
    bufferInfo = _serializer.float64(obj.base_to_left_back_leg, bufferInfo);
    // Serialize message field [base_to_right_front_leg]
    bufferInfo = _serializer.float64(obj.base_to_right_front_leg, bufferInfo);
    // Serialize message field [base_to_right_back_leg]
    bufferInfo = _serializer.float64(obj.base_to_right_back_leg, bufferInfo);
    // Serialize message field [wheel_to_left_front_leg]
    bufferInfo = _serializer.float64(obj.wheel_to_left_front_leg, bufferInfo);
    // Serialize message field [wheel_to_left_back_leg]
    bufferInfo = _serializer.float64(obj.wheel_to_left_back_leg, bufferInfo);
    // Serialize message field [wheel_to_right_front_leg]
    bufferInfo = _serializer.float64(obj.wheel_to_right_front_leg, bufferInfo);
    // Serialize message field [wheel_to_right_back_leg]
    bufferInfo = _serializer.float64(obj.wheel_to_right_back_leg, bufferInfo);
    return bufferInfo;
  }

  static deserialize(buffer) {
    //deserializes a message object of type msgMybot_detailMovement
    let tmp;
    let len;
    let data = new msgMybot_detailMovement();
    // Deserialize message field [header]
    tmp = std_msgs.msg.Header.deserialize(buffer);
    data.header = tmp.data;
    buffer = tmp.buffer;
    // Deserialize message field [left_wheel]
    tmp = _deserializer.float64(buffer);
    data.left_wheel = tmp.data;
    buffer = tmp.buffer;
    // Deserialize message field [right_wheel]
    tmp = _deserializer.float64(buffer);
    data.right_wheel = tmp.data;
    buffer = tmp.buffer;
    // Deserialize message field [base_to_left_front_leg]
    tmp = _deserializer.float64(buffer);
    data.base_to_left_front_leg = tmp.data;
    buffer = tmp.buffer;
    // Deserialize message field [base_to_left_back_leg]
    tmp = _deserializer.float64(buffer);
    data.base_to_left_back_leg = tmp.data;
    buffer = tmp.buffer;
    // Deserialize message field [base_to_right_front_leg]
    tmp = _deserializer.float64(buffer);
    data.base_to_right_front_leg = tmp.data;
    buffer = tmp.buffer;
    // Deserialize message field [base_to_right_back_leg]
    tmp = _deserializer.float64(buffer);
    data.base_to_right_back_leg = tmp.data;
    buffer = tmp.buffer;
    // Deserialize message field [wheel_to_left_front_leg]
    tmp = _deserializer.float64(buffer);
    data.wheel_to_left_front_leg = tmp.data;
    buffer = tmp.buffer;
    // Deserialize message field [wheel_to_left_back_leg]
    tmp = _deserializer.float64(buffer);
    data.wheel_to_left_back_leg = tmp.data;
    buffer = tmp.buffer;
    // Deserialize message field [wheel_to_right_front_leg]
    tmp = _deserializer.float64(buffer);
    data.wheel_to_right_front_leg = tmp.data;
    buffer = tmp.buffer;
    // Deserialize message field [wheel_to_right_back_leg]
    tmp = _deserializer.float64(buffer);
    data.wheel_to_right_back_leg = tmp.data;
    buffer = tmp.buffer;
    return {
      data: data,
      buffer: buffer
    }
  }

  static datatype() {
    // Returns string type for a message object
    return 'mybot_msg/msgMybot_detailMovement';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '233115fed7d58935e703c760f98369b3';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    Header header #Header for message type
    float64 left_wheel # velosity
    float64 right_wheel # velosity
    float64 base_to_left_front_leg # angle
    float64 base_to_left_back_leg # angle
    float64 base_to_right_front_leg # angle
    float64 base_to_right_back_leg # angle
    float64 wheel_to_left_front_leg # velosity
    float64 wheel_to_left_back_leg # velosity
    float64 wheel_to_right_front_leg # velosity
    float64 wheel_to_right_back_leg # velosity
    
    ================================================================================
    MSG: std_msgs/Header
    # Standard metadata for higher-level stamped data types.
    # This is generally used to communicate timestamped data 
    # in a particular coordinate frame.
    # 
    # sequence ID: consecutively increasing ID 
    uint32 seq
    #Two-integer timestamp that is expressed as:
    # * stamp.sec: seconds (stamp_secs) since epoch (in Python the variable is called 'secs')
    # * stamp.nsec: nanoseconds since stamp_secs (in Python the variable is called 'nsecs')
    # time-handling sugar is provided by the client library
    time stamp
    #Frame this data is associated with
    # 0: no frame
    # 1: global frame
    string frame_id
    
    `;
  }

};

module.exports = msgMybot_detailMovement;
